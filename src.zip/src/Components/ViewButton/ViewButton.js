import React from 'react'
import "./ViewButton.css"

function ViewButton() {
  return (
    <div className='parentViewButton'>

        <button type="submit" className='view_button' >VIEW</button> 
      
    </div>
  )
}

export default ViewButton
