import React from 'react'
import"./ProductImageDescription.css"

function ProductImageDescription() {
  return (
    <div className='ProductImageDescription'>
      
    </div>
  )
}

export default ProductImageDescription
