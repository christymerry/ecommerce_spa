import React from 'react'
import "./ProductTab.css"

function ProductTab() {
  return (
    <div className='parentProductTab'>
        
      
    </div>
  )
}

export default ProductTab
