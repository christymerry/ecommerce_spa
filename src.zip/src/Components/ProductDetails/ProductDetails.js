import React from 'react'
import Button from '../Button/Button'
import "./ProductDetails.css"

function ProductDetails() {
  return (
    <div className='parentProductDetails'>
      <div className="childparentProductDetails1">
        <div className="productImages">
          <img className='image1' src="../../../Images/dress2_1.png"alt=""/>
          

        </div>
        <div className="productalldetails">
          <h2 className='productalldetails_name'>Lantern Sleeve Plaid Tweed Dress</h2>
          <h5 className="product_price">£38.00 </h5>
          <div className="review">
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          </div>
          <p className='product_detail_description'>Color:	Multicolor
              Style:	Elegant
              Pattern Type:	Plaid
              Details:	Zipper
              Type:	A Line
              Neckline:	Stand Collar
              Sleeve Length:	Long Sleeve
              Sleeve Type:	Bishop Sleeve
              Waist Line:	High Waist
              Hem Shaped:	Straight
              Length:	Short
              Fit Type:	Regular Fit
              Fabric:	Non-Stretch
              Material:	Tweed
              Composition:	100% Polyester
              Care Instructions:	Machine wash or professional dry clean
              Sheer:	No</p>
              <div className="addToBag">
                <div className="selectOption">
                  <select name="count" className="count_productdetails">
                    <option value="1"><b>Qty:</b>  1</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  
                  </select>
                </div>
                <div className="button_addtocart">
                  <Button className="addtobag" buttonName="ADD TO BAG" iconname="fa fa-shopping-bag"/>
                </div>
              </div>
              <p className='condition'> <b>Free </b>standard home delivery on orders over £40</p> 
              <p className='condition'> <b> Free </b> delivery to store - with Click & Collect*</p> 
              <p className='condition'><b>Free </b> returns to store</p>
              
        </div>
      </div>
      <div className="childparentProductDetails2">
      
                <h2>Product Info</h2>
                <p className='childparentProductDetails2_detail'>Add something a little different to your selection of versatile staples with this burgundy pinafore dress. Crafted from cotton cord for a soft, textured finish, the pinny can easily be worn with tees and trainers in the summer months or turtle necks and tights when the temperature starts to drop. With silver strap fastenings and functional front pockets, this year-round staple is all set to top the list of your favourites. Model Height: 5ft 9. </p>
                <h5>Additional Details</h5>
                <p className="childparentProductDetails2_detail">100% Cotton</p>
                <h5>Care</h5>
                <p className="childparentProductDetails2_detail">Machine Washable</p>
                <h5>Share On</h5>
                <div className="shareSocialMedia">
                  <a href="#" className='socialmediaicon' class="fa fa-facebook"></a>
                  <a href="#" className='socialmediaicon' class="fa fa-twitter"></a>
                  <a href="#" className='socialmediaicon' class="fa fa-google"></a>
                </div>
             
      </div>
      
    
    </div>
  )
}

export default ProductDetails
