import React, { useState, useContext} from 'react'
import { useLocation } from 'react-router-dom'
import { FirebaseContext } from '../../Store/FirebaseContext';
import InputField from '../InputField/InputField'
import './CreateAccount.css'

function CreateAccount() {
    const {state} = useLocation();
    const{email1}= state;
    console.log(email1);
    const [email,setEmail]=useState(email1);
    const [password,setPassword]=useState('');
    const [firstName,setfirstName]=useState('');
    const [lastName,setlastName]=useState('')
    const{firebase}=useContext(FirebaseContext);
    const onChangeEmaillogin = (val) => {
        setEmail(val);
        
    }
    const onChangePassword = (val) => {
        setPassword(val);
        
    }
    const onChangefirstName = (val) => {
        setfirstName(val);
        
      }
      const onChangelastName = (val) => {
        setlastName(val);
        
      }
    


const handleSubmitCreateAccount=()=>{
    
    
   
    

}
  return (
    <form onSubmit={handleSubmitCreateAccount}>
    
    <div className='parentCreateAcount'>
        <h2 className='parentCreateAcountTitle'>Create your account</h2>
        <p className='parentCreateAcount_desc'>We are delighted to have you as part of the family. All we ask is that you fill in the missing details highlighted in the form below:</p>
        <div className="accountdetails">
            <div className="accountdetails1">
                <InputField value={firstName} onChange={onChangefirstName} placeholder="First Name" inputName="First Name"/>
                <InputField value={email} onChange={onChangeEmaillogin} placeholder="Email Address" inputName="EmailAddress"/>
                <InputField value={password} onChange={onChangePassword} placeholder="Enter Password" inputName="Password"/>
            </div>
            <div className="accountdetails2">
                <InputField value={lastName} onChange={onChangelastName} placeholder="Last Name" inputName="Last Name"/>
                <InputField  placeholder="Confirm Email Address" inputName="Confirm Email Address"/>
                <InputField placeholder="Confirm Password" inputName="Confirm Password"/>

            </div>
        </div>
        <div className='createAccountButton'>
            <button type="submit" className='createAccountButtonSubmit' >CREATE ACCOUNT</button>
        </div>

    </div>
    </form>
  )
  
}

export default CreateAccount
