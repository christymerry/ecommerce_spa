import "./ProductImage.css"
import React from 'react'
import ViewButton from "../ViewButton/ViewButton"

function ProductImage() {
  return (
    <div className="parentProductImage">
      <div className="parentProductImage1">
        <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress1_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress1_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress1_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>
        <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress2_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress2_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress2_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>
        <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress3_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress3_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress3_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>
        <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress4_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress4_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress4_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>

      </div>
      <div className="parentProductImage2">
      <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress5_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress5_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress5_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>
        <div className="parentProductImage1_detail">
        <img className="productimage"
          src="../../../Images/dress6_1.png"
          onMouseOver={e => (e.currentTarget.src = "../../../Images/dress6_1.png")}
          onMouseOut={e => (e.currentTarget.src = "../../../Images/dress6_2.png")}
          >

        </img>
        <p>Lantern Sleeve Plaid Tweed Dress</p>
        <h3 className="product_price">£38.00</h3>
        <ViewButton/>
        </div>
        
        

      </div>
        
      </div>
  )
}

export default ProductImage
