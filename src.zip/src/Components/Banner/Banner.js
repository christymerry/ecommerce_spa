import React from 'react'

function Banner() {
  return (
    
      <div className="banner">
            <img className='banner_Image'
                        src="../../../Images/banner.png"
                        alt="image"
            />

        </div>
  
  )
}

export default Banner
