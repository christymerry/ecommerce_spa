import React from 'react'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import ProductDetails from '../Components/ProductDetails/ProductDetails'
import ProductTab from '../Components/ProductTab/ProductTab'

function ProductDetail() {
  return (
    <div>
        <Header/>
        <ProductDetails/>
        <ProductTab/>
        <Footer/>
    </div>
  )
}

export default ProductDetail
