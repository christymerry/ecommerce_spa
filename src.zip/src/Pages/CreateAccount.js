import React from 'react'
import CreateAccount from '../Components/CreateAccount/CreateAccount'

function CreateAccountPage() {
  return (
    <div>
      <CreateAccount/>
    </div>
  )
}

export default CreateAccountPage
