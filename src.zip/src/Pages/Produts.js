import React from 'react'
import BreadCrumps from '../Components/BreadCrumps/BreadCrumps'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import ProductCategoryOption from '../Components/ProductCategoryOption/ProductCategoryOption'
import ProductDescription from '../Components/ProductDescription/ProductDescription'
import ProductImage from '../Components/ProductImage/ProductImage'
import './style.css'


function Produts() {
  return (
    <div className='parentProducts'>
        <Header/>
        <BreadCrumps data="Womens"/>
        <div className='product'>
          <ProductCategoryOption/>
          <div class="productmain">
            <ProductDescription/>
            <ProductImage/>
          </div>
        </div>
        <Footer/>
    </div>
  )
}

export default Produts
